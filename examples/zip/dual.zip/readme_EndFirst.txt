You are using: *** END-FIRST TYPE EXTRACTOR ***
The End-first extractors are the most common ones. They look for the
end-of-central-directory header at the end of the file, which is the
most probable place the header is found.
